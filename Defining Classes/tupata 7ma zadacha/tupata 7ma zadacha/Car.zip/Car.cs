﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Car
    {

        public Car
            (
            string model,
            int speed,
            int power,
            int weight,
            string type,
            double press1ure,
            int age1,
            double press2ure,
            int age2,
            double press3ure,
            int age3,
            double press4ure,
            int age4
            )
        {
            Model = model;
            Engine = new Engine { Speed = speed, Power = power};
            Cargo = new Cargo { Weight = weight, Type = type};
            Tires = new Tires[4];
            Tires[0] = new Tires {Pressure = press1ure, Age = age1 };
            Tires[1] = new Tires {Pressure = press2ure, Age = age2 };
            Tires[2] = new Tires {Pressure = press3ure, Age = age3 };
            Tires[3] = new Tires {Pressure = press4ure, Age = age4 };
        }

        public string Model { get; set; }

        public Engine Engine { get; set; }

        public Cargo Cargo { get; set; }

        public Tires[] Tires { get; set; }
    }
}
