﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacture
{
    internal class Car
    {
    }
}
