﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {
        private string Make { get; set; }
        private string Model { get; set; }
        private int Year { get; set; }
    }
}
