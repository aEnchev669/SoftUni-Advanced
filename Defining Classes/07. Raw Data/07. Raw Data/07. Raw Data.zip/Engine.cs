﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Raw_Data
{
    public class Engine
    {
        private int speed;
        public  int Speed { get => speed; set => speed = value; }

        private int power;
        public  int Power{ get => power; set => power = value; }
    }
}
